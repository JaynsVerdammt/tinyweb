#!/usr/bin/perl

# hello.pl -- my first perl script!

print "Content-type: text/html\r\n\r\n";

print <<"EOF";
<HTML>

<HEAD>
<TITLE>Hello, world!</TITLE>
</HEAD>

<BODY>
<H1>Hello, world!</H1>
</BODY>

</HTML>
EOF

