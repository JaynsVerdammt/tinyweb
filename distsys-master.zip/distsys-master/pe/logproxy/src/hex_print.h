
/*
 * hex_print.h
 *
 *
 * $Id: hex_print.h,v 1.2 2005/11/18 22:14:38 ralf Exp $
 *
 */

#ifndef HEX_PRINT_H
#define HEX_PRINT_H

extern void hex_print(FILE *fd, const char *s, ushort len, ushort offset);

#endif
