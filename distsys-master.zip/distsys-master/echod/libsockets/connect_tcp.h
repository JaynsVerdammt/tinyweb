/*
 * connect_tcp.h
 *
 * $Id: connect_tcp.h,v 1.2 2004/12/29 00:37:29 ralf Exp $
 *
 */

#ifndef _CONNECT_TCP_H
#define _CONNECT_TCP_H

int connect_tcp(const char *host, unsigned short port);

#endif
